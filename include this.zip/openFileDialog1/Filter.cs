﻿namespace openFileDialog1
{
    internal class Filter
    {
    }
}